// app.js - minimal interactivity
document.addEventListener('click', function(e){
  // bisa ditambah nanti
});
